import numpy as np

class DataPoint:
    def __init__(self, record):
        self.value = record
        self.cluster = None

    def getValue(self):
        return self.value

    def setCluster(self, _cluster):
        self.cluster = _cluster

    def getCluster(self):
        return self.cluster

    # Euclidean Distance Caculator
    def dist(self,b, ax=1):
        return np.linalg.norm(self.value - b, axis=ax)
