import numpy as np
from phe import paillier
import pickle
import copy
import json
import time
import io
import subprocess

# Euclidean Distance Caculator
def dist(a, b, ax=0):
    return np.linalg.norm(a - b)

#Find out if the new means
#are sufficiently close to old means
def checkThreshold(means_, means, k, n, partyNumber, totalParties, partyBindSocketPr, requestSocket, replySocket, broadcastSocketsPr):
    d = 0
    for i in range(k):
        d = d + np.absolute(dist(means_[i], means[i]))   
    #securely compute if d ≤ T h.
    m = None

    if partyNumber == 0:
        m = np.random.uniform(0, n-1, 1)
        terminatonThreshold = 1.2
        message = requestSocket.recv()
        requestSocket.send(pickle.dumps(m))
        Th_ = terminatonThreshold
        message = replySocket.recv()
        proc = subprocess.check_output(["./emp-sh2pc/bin/example", "1", "12345", str(Th_*1000)])
        print("result 1 ----", int(str(proc)[-4]))
        #if m is bigger than threshold, tell all parties to stop
        #1 stop, 0 continue
        return int(str(proc)[-4])
        
    if partyNumber != totalParties - 1 and partyNumber != 0:
        replySocket.send(b"start")
        m = pickle.loads(replySocket.recv())
        requestSocket.send(pickle.dumps(((m + d)%n))) #% n))
        termination = pickle.loads(partyBindSocketPr.recv())
        return termination
    else:
        if partyNumber == totalParties - 1: 
            m = pickle.loads(replySocket.recv())
            m = m + d
            m = m % n
            requestSocket.send(b"message")
            proc = subprocess.check_output(["./emp-sh2pc/bin/example", "2", "12345", str(float(m)*1000)])
            print("result r ----", int(str(proc)[-4]))
            for i in range(1,totalParties-1):
                broadcastSocketsPr[i].send(pickle.dumps(int(str(proc)[-4])))
            return int(str(proc)[-4])

#Find minimum distance cluster
#Require: r parties, each with a length k vector X
# of distances. Three of these parties (trusted not to collude) are labeled P 1 , P 2 , and P r .
def closest_cluster(X, party, totalParties, numClusters, broadcastSockets, partyBindSocket, broadcastSocketsPr, partyBindSocketPr, n):
    #P1 P2 Pr
    T_i = None
    pi = None
    if party == 0:
        #stage 1
        #P 1 generates r random vectors V ~ i summing to ~ 0
        V = genRandom( totalParties,numClusters, n)
        #P 1 generates a random permutation π over k elements
        pi = np.random.permutation(numClusters)
        print("process ",party)
        for i in range(1,totalParties):
            permutationP1(broadcastSockets[i], V[i], pi)
        T_i = []
        for x in pi:
            T_i.append(X[x] + V[0][x])
            emitAddMetric()
        #print(X,party)
    else : 
        print("process ", party)
        T_i = permutationPi(partyBindSocket,X)

    if party == totalParties - 1:
        Y = [x for x in T_i]
        for i in range(0,totalParties-1):
            if i != 1:
                broadcastSocketsPr[i].send(b"Start stage 2")
                T_i_ = pickle.loads(broadcastSocketsPr[i].recv())
                #print(T_i,i)
                for x in range(0,len(Y)):
                    Y[x] = Y[x] + T_i_[x]
                    emitAddMetric()
        #print(Y)
        #stage 3 between P2 and Pr
        minimal = 0
        deltaY = abs(Y[1] - Y[0])
        broadcastSocketsPr[1].send(b"start")
        
        arr = []
        for j in range(1,numClusters):
            arr.append(abs(Y[minimal]-Y[j]))
           # print(secureAddAndComparePr(Y[minimal],Y[j]),"Pr")
            if secureAddAndComparePr(Y[minimal],Y[j]) == 1:
                emitComparisonsMetric()
                minimal = j     
        #print(minimal , "-----------", party)
       # print(arr, "   ", min(arr))    
       #Stage 4
       #Party P r sends minimal to P 1
        partyBindSocket.send(pickle.dumps(minimal))
        
    else:
        if party != 1:
            message = partyBindSocketPr.recv()
            partyBindSocketPr.send(pickle.dumps(T_i))
        else:
            if party == 1:
                #stage 3 between P2 and Pr
                minimal = 0
                #deltaT2 = abs(T_i[0] - T_i[1])
                message = partyBindSocketPr.recv()
                arr = []
                for j in range(1,numClusters):
                    arr.append(abs(T_i[minimal]-T_i[j]))
                   # print(secureAddAndCompareP2(T_i[minimal],T_i[j]),"P2")
                    if secureAddAndCompareP2(T_i[minimal],T_i[j]) == 1:
                        emitComparisonsMetric()
                        minimal = j
                #print(minimal,"---------",party)
                #print(arr, "   ", min(arr))    
    if party == 0:
        minimal = pickle.loads(broadcastSockets[totalParties-1].recv())
        #print("pi",pi,minimal)
        minimal = pi[minimal]
        #print("minimal",minimal)
        for x in range(1,totalParties):
            broadcastSockets[x].send(pickle.dumps(minimal))
        return minimal
    else :
        minimal = pickle.loads(partyBindSocket.recv())
        return minimal

# Require: Random number generator rand producing val-
# ues uniformly distributed over 0..n − 1 spanning (at
# least) the domain of the distance function − D .
# Ensure: The sum of the resulting vectors is 0.
# Generates a (somewhat) random matrix V k×r
def genRandom(k, r, n):
    partSum = [0 for x in range(0,k)]
    V = np.zeros((k,r))
    for i in range(0,k):
        partSum[i] = 0
        for j in range(1,r):
            V[i][j] = np.random.uniform(0,n-1,1)
            partSum[i] = (partSum[i] + V[i][j]) % n
            emitAddMetric()
        V[i][0] = (partSum[i]*(-1)) % n
    return V

def permutationPi(socket, X):#B
    startMessage = socket.recv_string()
    public_key1, private_key = paillier.generate_paillier_keypair()
    encr_X = [public_key1.encrypt(x) for x in X]
    socket.send(pickle.dumps(public_key1))
    message = socket.recv()
    socket.send(pickle.dumps(encr_X))
    T_p_ = pickle.loads(socket.recv())
    T_p = []
    for el in T_p_:
        T_p.append(private_key.decrypt(el))
    return T_p
    
def permutationP1(socket, V, pi):#A
    socket.send(b"Echo")
    public_key = pickle.loads(socket.recv())
    socket.send(b"received key")
    encr_X = pickle.loads(socket.recv())
    V_ = [public_key.encrypt(x) for x in V]
    T_ = []
    for i in range(0,len(V)):
        T_.append(V_[i] + encr_X[i])
        emitAddMetric()
    T_p_ = [T_[x] for x in pi]
    socket.send(pickle.dumps(T_p_))

def secureAddAndCompareP2(A1,A2):
    #print("A ",str(abs(A1-A2)*1000))
    proc = subprocess.check_output(["./emp-sh2pc/bin/example", "1", "12345", str(abs(A1-A2)*1000)]) 
    #proc = subprocess.Popen(["./emp-sh2pc/bin/example", "1", "12345", str(abs(A1-A2))], stdout=subprocess.PIPE,bufsize=1, universal_newlines=True)
    if int(str(proc)[-4]) == 1:
        return 0
    return 1
        

def secureAddAndComparePr(B1,B2):
   # print("B ",str(abs(B1-B2)*1000))
    proc = subprocess.check_output(["./emp-sh2pc/bin/example", "2", "12345", str(abs(B1-B2)*1000)])
   # proc = subprocess.Popen(["./emp-sh2pc/bin/example", "2", "12345", str(abs(B1-B2))], stdout=subprocess.PIPE,bufsize=1, universal_newlines=True)
    if int(str(proc)[-4]) == 0:
        return 1
    return 0

def emitAddMetric():
    f = open("sum.txt", "a+")
    f.write("0")
    f.close()

def emitComparisonsMetric():
    f = open("comparisons.txt", "a+")
    f.write("0")
    f.close()

def writeMeans(means, procNumber, k):
    f = open("data/means"+str(procNumber)+"k"+str(k)+".txt","w+")
    f.write(str(means))
    f.close()

def clusterCohesion(means, clusters, procNumber, k):
    sum_C= 0
    for i in range(k):
        sum = 0
        for j in range(len(clusters[i])):
            sum = sum + dist(means[i],clusters[i][j])
        if len(clusters[i]) > 0:
            sum = sum / len(clusters[i])
        sum_C = sum_C + sum
    sum_C = sum_C /(k)
    f = open("clustercohesion"+str(procNumber)+"k"+str(k)+".txt","w+")
    f.write(str(sum_C))
    f.close()