import csv
import sys 
import subprocess
import random 
import csv
import os
import time
from multiprocessing import Pool

def run_process(process):                                                             
    os.system(process)

sampleSize = 5

def createDataSource(party, records):
    attributes = [x for x in range(party * sampleSize, party * sampleSize + sampleSize)]
    with open('data/records'+str(party)+'.csv','w+',newline='') as outputFile:
        for record in records:
            subset_record = []
            for attribute in attributes:
                subset_record.append(record[attribute])
            wr = csv.writer(outputFile, quoting=csv.QUOTE_ALL)
            wr.writerow(subset_record)
        

data = []

with open('small.csv', 'r') as file:
    csvreader = csv.reader(file)
    for row in csvreader:
        data.append(row[4:]) #ignore fields such as patient_id, sex and age
    del(data[0])

numClusters = int(sys.argv[1])
numParties = int(sys.argv[2])
numIters = int(sys.argv[3])
port = int(sys.argv[4])


otherParties = []
primaryParty = ["python3 "+"party.py " + "0" + " "+str(numParties) + " " + str(numClusters) + " " + str(numIters) + " " + str(port)]

createDataSource(0, data)

for i in range(1,numParties):
    createDataSource(i, data)
    otherParties.append("python3 "+"party.py " + str(i) + " "+str(numParties) + " " + str(numClusters) + " " + str(numIters) + " " + str(port) +" &" )
    #os.system("python3 "+"party.py " + str(i) + " "+str(numParties) + " " + str(numClusters) + " " + str(numIters) + " " + str(port) + " " + "&")
    #subprocess.call(["python3", "party.py",str(i),str(numParties),str(numClusters),str(numIters),str(port),"&"])
#otherParties[numParties-2] = otherParties[numParties-2][:-1]
#print(primaryParty,otherParties)
pool = Pool(processes=numParties)
pool.map(run_process, otherParties)
pool.map(run_process, primaryParty)