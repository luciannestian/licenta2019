import zmq
import time
import sys
import csv
import numpy as np
from point import DataPoint
import algorithms
import socket
from math import sqrt
import copy
import math

clientPrefix="tcp://127.0.0.1:"
genericData="publicKey"

broadcastSockets = []
broadcastSocketsPr = []

partyNumber = int(sys.argv[1])
totalParties = int(sys.argv[2])
k = int(sys.argv[3])
iters = int(sys.argv[4])
n = int(sys.argv[5])

basePort = int(sys.argv[6])
broadcastPort = basePort + 100

context = zmq.Context()

partyBindSocket = None
partyBindSocketPr = None

requestSocket = context.socket(zmq.PAIR)
replySocket = context.socket(zmq.PAIR)

if partyNumber == totalParties - 1:
    replySocket.bind(clientPrefix + str(basePort + 2000 + partyNumber))
    requestSocket.connect(clientPrefix + str(basePort + 2000 )) # Pr to P1
else:
    replySocket.bind(clientPrefix + str(basePort + 2000 + partyNumber))
    requestSocket.connect(clientPrefix + str(basePort + 2000 + partyNumber + 1))
    
sock = None
if partyNumber > 0:
    partyBindSocket = context.socket(zmq.PAIR)
    partyBindSocket.bind(clientPrefix + str(broadcastPort+partyNumber))

    broadcastSockets = None
    # sock = context.socket(zmq.PAIR)
    # sock.connect("tcp://127.0.0.1:5679")
    pass
else:
    broadcastSockets.append(None)
    for i in range(1,totalParties):
        broadcastSockets.append(context.socket(zmq.PAIR))
        broadcastSockets[i].connect(clientPrefix + str(broadcastPort+i))
    # sock = context.socket(zmq.PAIR)
    # sock.bind("tcp://127.0.0.1:5679")

#for stage 2
if partyNumber != totalParties-1:
    partyBindSocketPr = context.socket(zmq.PAIR)
    partyBindSocketPr.bind(clientPrefix + str(broadcastPort+partyNumber+1000))
else:
    for i in range(0,totalParties-1):
        broadcastSocketsPr.append(context.socket(zmq.PAIR))
        broadcastSocketsPr[i].connect(clientPrefix + str(broadcastPort+i+1000))

timing = [time.time()]

medicalRecords = []

with open('data/records'+str(partyNumber)+'.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        medicalRecords.append(row)

points = np.array(medicalRecords)
points = points.astype(np.float)

means = []
means_ = []
terminate = 0
iteration = 0
clusters = []
for i in range(0,k):
    means_.append(points[i])

while terminate == 0 and iteration < iters:
    print("------------------------ITERATIA ", iteration)
    iteration += 1
    clusters = []

    means = copy.deepcopy(means_)
    for i in range(k):
        clusters.append([])

    X = [] #dist vector

    for g in points:
        X = []
        for i in range(0,k):
            x = np.absolute(algorithms.dist(g,means[i]))
            X.append(x)
        closestCluster = algorithms.closest_cluster(X, partyNumber, totalParties, k, broadcastSockets, partyBindSocket,broadcastSocketsPr, partyBindSocketPr, n)
        #print(partyNumber,closestCluster)
        clusters[closestCluster].append(g)
 #   print(means, "party ", partyNumber)
  #  print(clusters,"clusters party ",partyNumber)

    # Finding the new centroids by taking the average value
    for i in range(k):
        attributes = [[] for x in range(0,len(means[0]))]
        for j in range(len(means[0])):
            for point in clusters[i]:
                attributes[j].append(point[j])
        
        #print("cluster ",i," ",attributes," party ",partyNumber)
        #data = [points[j] for j in range(len(points)) if clusters[j] == i]
        for j in range(len(means[0])):
            if attributes[j] != []:
                means_[i][j] = np.mean(attributes[j])
            else: means_[i][j] = 0
        for mean in means_:
            for val in mean:
                if math.isnan(val):
                    val = 0
    #print(attributes,"attributes party ",partyNumber)
    #algorithms.closest_cluster(X, partyNumber, totalParties, k, broadcastSockets, partyBindSocket,broadcastSocketsPr, partyBindSocketPr) 
    print(means_,"new means party ",len(means_), partyNumber)
    algorithms.writeClusterCohesion(means_,clusters,k,partyNumber,iters)
    terminate = algorithms.checkThreshold(means_, means, k, n, partyNumber, totalParties, partyBindSocketPr, requestSocket, replySocket, broadcastSocketsPr)
    print("terminate : ",terminate, " party ", partyNumber)
algorithms.writeMeans(means, partyNumber, k)
print('s-a terminat party ->', partyNumber)