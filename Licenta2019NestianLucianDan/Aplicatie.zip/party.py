import zmq
import time
import sys
import csv
import numpy as np
from point import DataPoint
import algorithms
import socket
from math import sqrt
import copy

# Euclidean Distance Caculator
def dist(a, b, ax=0):
    return np.linalg.norm(a - b)

clientPrefix="tcp://127.0.0.1:"
serverPrefix="tcp://*:"
genericData="publicKey"

broadcastSockets = []
broadcastSocketsPr = []

partyNumber = int(sys.argv[1])
totalParties = int(sys.argv[2])
k = int(sys.argv[3])
iters = int(sys.argv[4])

basePort = int(sys.argv[5])
broadcastPort = basePort + 100

context = zmq.Context()

partyBindSocket = None
partyBindSocketPr = None

# requestSocket.connect(clientPrefix + str(basePort + partyNumber + 1))
# replySocket.bind(serverPrefix + str(basePort + partyNumber))
sock = None
if partyNumber > 0:
    partyBindSocket = context.socket(zmq.PAIR)
    partyBindSocket.bind(clientPrefix + str(broadcastPort+partyNumber))

    broadcastSockets = None
    # sock = context.socket(zmq.PAIR)
    # sock.connect("tcp://127.0.0.1:5679")
    pass
else:
    broadcastSockets.append(None)
    for i in range(1,totalParties):
        broadcastSockets.append(context.socket(zmq.PAIR))
        broadcastSockets[i].connect(clientPrefix + str(broadcastPort+i))
    # sock = context.socket(zmq.PAIR)
    # sock.bind("tcp://127.0.0.1:5679")

#for stage 2
if partyNumber != totalParties-1:
    partyBindSocketPr = context.socket(zmq.PAIR)
    partyBindSocketPr.bind(clientPrefix + str(broadcastPort+partyNumber+1000))
else:
    for i in range(0,totalParties-1):
        broadcastSocketsPr.append(context.socket(zmq.PAIR))
        broadcastSocketsPr[i].connect(clientPrefix + str(broadcastPort+i+1000))

timing = [time.time()]

medicalRecords = []

with open('data/records'+str(partyNumber)+'.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        medicalRecords.append(row)

points = np.array(medicalRecords)
points = points.astype(np.float)

means = []
clusters = []

for i in range(0,k):
    means.append(points[i])
    clusters.append([])

X = []

for g in points:
    X = []
    for i in range(0,k):
        x = dist(g,means[i])
        X.append(x)
    closestCluster = algorithms.closest_cluster(X, partyNumber, totalParties, k, broadcastSockets, partyBindSocket,broadcastSocketsPr, partyBindSocketPr)
    #print(partyNumber,closestCluster)
    clusters[closestCluster].append(g)
print(clusters,"party ",partyNumber)

# Storing the old centroid values
old_means = copy.deepcopy(means)
# Finding the new centroids by taking the average value
#for i in range(k):
    #data = [points[j] for j in range(len(points)) if clusters[j] == i]
    #means[i] = np.mean(points)
#algorithms.closest_cluster(X, partyNumber, totalParties, k, broadcastSockets, partyBindSocket,broadcastSocketsPr, partyBindSocketPr) 

print('SA va iau in pwla de rockeri', partyNumber)


