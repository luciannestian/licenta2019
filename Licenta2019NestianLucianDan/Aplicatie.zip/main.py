import csv 
import numpy as np
import copy 
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs


parsed_data = []

with open('small.csv', 'r') as csvfile:
    spamreader = csv.reader(csvfile)
    for row in spamreader:
        parsed_data.append(row[3:])
    del(parsed_data[0])
        

# Euclidean Distance Caculator
def dist(a, b, ax=1):
    return np.linalg.norm(a - b, axis=ax)

X = np.array(parsed_data)
X = X.astype(np.float)


# Number of clusters
k = 3

# # X coordinates of random centroids
# C_x = np.random.randint(0, np.max(X), size=k)
# # Y coordinates of random centroids
# C_y = np.random.randint(0, np.max(X), size=k)
# C = np.array(list(zip(C_x, C_y)), dtype=np.float32)

C = [] 
C_coord = np.random.randint(0, len(X), size=k)

for i in range(0,k):
    C.append(X[C_coord[i]])
C = np.array(C, dtype=np.float32)
#print(C)
# To store the value of centroids when it updates
C_old = np.zeros(C.shape)
# Cluster Lables(0, 1, 2)
clusters = np.zeros(len(X))
# Error func. - Distance between new centroids and old centroids
error = dist(C, C_old, None)
# Loop will run till the error becomes zero
while error != 0:
    # Assigning each value to its closest cluster
    for i in range(len(X)):
        #print(X[i])
        distances = dist(X[i], C)
        cluster = np.argmin(distances)
        clusters[i] = cluster
    # Storing the old centroid values
    C_old = copy.deepcopy(C)
    # Finding the new centroids by taking the average value
    for i in range(k):
        points = [X[j] for j in range(len(X)) if clusters[j] == i]
        C[i] = np.mean(points, axis=0)
    error = dist(C, C_old, None)
