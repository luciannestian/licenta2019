git clone https://github.com/emp-toolkit/emp-readme.git
bash ./emp-readme/scripts/install_packages.sh
bash ./emp-readme/scripts/install_relic.sh
bash ./emp-readme/scripts/install_emp-tool.sh
bash ./emp-readme/scripts/install_emp-ot.sh
bash ./emp-readme/scripts/install_emp-m2pc.sh
bash ./emp-readme/scripts/install_emp-sh2pc.sh
